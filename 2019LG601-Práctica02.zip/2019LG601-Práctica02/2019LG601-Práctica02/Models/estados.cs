﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace _2019LG601_Práctica02.Models
{
    public class estados
    {
        [Key]
        public int estado_equipo_id { get; set; }
    }
}
