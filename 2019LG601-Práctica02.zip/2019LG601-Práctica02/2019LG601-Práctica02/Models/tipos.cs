﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace _2019LG601_Práctica02.Models
{
    public class tipos
    {
        [Key]
        public int tipo_equipo_id { get; set; }
    }
}
