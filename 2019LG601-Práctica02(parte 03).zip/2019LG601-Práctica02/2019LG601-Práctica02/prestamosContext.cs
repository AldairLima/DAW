﻿using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using _2019LG601_Práctica02.Models;

namespace _2019LG601_Práctica02
{
    public class prestamosContext: DbContext
    {
        public prestamosContext(DbContextOptions<prestamosContext> options) : base(options)
        {

        }
        public DbSet<equipos> equipos { get; set; }
    }
    
}
