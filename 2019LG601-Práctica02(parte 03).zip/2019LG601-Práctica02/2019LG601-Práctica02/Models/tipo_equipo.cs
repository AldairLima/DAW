﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _2019LG601_Práctica02.Models
{
    public class tipo_equipo
    {
    }
}
