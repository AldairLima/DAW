using System;
using System.ComponentModel.DataAnnotations;
namespace _2019LG601.Models
{
    public class marcas{
         [Key]
        public int estado_equipo_id { get; set; }
    }
}