using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using prestasmosApi.Models;

namespace  _2019LG601
{
    public class tipoContext : DbContext
    {
        public tipoContext(DbContextOptions<tipoContext> options) : base(options)
        {            
        }

        public DbSet<equipos> tipo {get; set;}
    }
}