using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using prestasmosApi.Models;

namespace _2019LG601.Controllers
{
    [ApiController] 
    public class equiposController : ControllerBase
    {
        private readonly _2019LG601Context _contexto;

        public equiposController(_2019LG601Context miContexto) {
            this._contexto = miContexto;
        }

        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get(){
            var marcasList = _contexto.equipos;
            if(marcasList.Count>0){
                return Ok(equiposList);
            }
            return NotFound();            
        } 

    }
}