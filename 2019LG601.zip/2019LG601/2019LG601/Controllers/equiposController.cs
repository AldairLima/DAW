using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using prestasmosApi.Models;

namespace _2019LG601.Controllers
{
    [ApiController] 
    public class equiposController : ControllerBase
    {
        private readonly _2019LGContext _contexto;

        public equiposController(_2019Context miContexto) {
            this._contexto = miContexto;
        }

        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get(){
            var equiposList = _contexto.equipos;
            if(equiposList.Count>0){
                return Ok(equiposList);
            }
            return NotFound();            
        } 

    }
}